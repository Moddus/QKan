from .application import Substanzklasse
