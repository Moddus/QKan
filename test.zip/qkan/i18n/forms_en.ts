<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>Direkteinleitungen</name>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="23"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="36"/>
        <source>zu Haltung</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="52"/>
        <source>Wasserverbrauch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="68"/>
        <source>Teilgebiet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="114"/>
        <source>l/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="127"/>
        <source>Strasse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="170"/>
        <source>Nr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="183"/>
        <source>Zusatz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="206"/>
        <source>Kommentar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="219"/>
        <source>Erstelldatum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="235"/>
        <source>Einzugsgebiet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="271"/>
        <source>Bezeichnung</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_einleit.ui" line="290"/>
        <source>dd.MM.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="20"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="33"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="189"/>
        <source>Erstelldatum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="228"/>
        <source>Kommentar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="374"/>
        <source>dd.MM.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="127"/>
        <source>Abflussbeiwert </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_abflussparameter.ui" line="189"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Startwert für den Abflussbeiwert in HYSTEM-EXTRAN (0.0 - 1.0)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_abflussparameter.ui" line="192"/>
        <source>Startwert für den Abflussbeiwert in HYSTEM-EXTRAN (0.0 - 1.0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="151"/>
        <source>Anfang</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_abflussparameter.ui" line="208"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Endwert für den Abflussbeiwert in HYSTEM-EXTRAN (0.0 - 1.0)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="176"/>
        <source>Ende</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_kp_abflussparameter.ui" line="159"/>
        <source>endabflussbeiwert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_kp_abflussparameter.ui" line="191"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="271"/>
        <source>Verlustbeiwerte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_schaechte.ui" line="224"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="337"/>
        <source>Benetzungsverlust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="356"/>
        <source>Benetzungsstartwert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="404"/>
        <source>Muldenverlust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="423"/>
        <source>Muldenstartwert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_abflussparameter.ui" line="495"/>
        <source>Weitere Parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_kp_abflussparameter.ui" line="124"/>
        <source>Bodenklasse. Muss bei befestigten Flächen leer sein.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_kp_abflussparameter.ui" line="127"/>
        <source>bodenklasse</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_abflussparameter.ui" line="551"/>
        <source>Flächentyp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_kp_abflussparameter.ui" line="140"/>
        <source>Bodenklasse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungageb.ui" line="36"/>
        <source>Bezeichnung:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungageb.ui" line="62"/>
        <source>zu Schacht:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungageb.ui" line="88"/>
        <source>Teilgebiet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_tezg.ui" line="49"/>
        <source>Bezeichnung</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_tezg.ui" line="36"/>
        <source>zu Haltung</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_tezg.ui" line="101"/>
        <source>Teilgebiet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungflaechen.ui" line="75"/>
        <source>Verbindungsdaten</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_anbindungflaechen.ui" line="127"/>
        <source>Haltungsfläche (tezg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_teilgebiete.ui" line="192"/>
        <source>Fläche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungflaechen.ui" line="195"/>
        <source>Abflussmodellierung</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungflaechen.ui" line="224"/>
        <source>Speicherkonstante</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungflaechen.ui" line="247"/>
        <source>Abflussmodell</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungflaechen.ui" line="270"/>
        <source>Anzahl Speicher</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_anbindungflaechen.ui" line="293"/>
        <source>Fließzeit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_anbindungflaechen.ui" line="399"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_anbindungflaechen.ui" line="346"/>
        <source>Fließzeit Kanal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="413"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_speicher.ui" line="72"/>
        <source>Deckelhöhe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_speicher.ui" line="111"/>
        <source>m NHN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_speicher.ui" line="124"/>
        <source>Y-Koordinate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_speicher.ui" line="85"/>
        <source>X-Koordinate</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_speicher.ui" line="137"/>
        <source>Sohlhöhe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_auslaesse.ui" line="205"/>
        <source>Auslasstyp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_speicher.ui" line="176"/>
        <source>Simulationsstatus</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_auslaesse.ui" line="231"/>
        <source>Entwässerungsart</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_speicher.ui" line="301"/>
        <source>Straße</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_speicher.ui" line="365"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Hier kann der Knotentyp geändert werden&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_speicher.ui" line="371"/>
        <source>Hier kann der Knotentyp geändert werden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="46"/>
        <source>Typ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_simulationsstatus.ui" line="36"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;Hystem-Extran-Nr :&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_simulationsstatus.ui" line="52"/>
        <source>Mike-Urban-Nr :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_simulationsstatus.ui" line="68"/>
        <source>Kanal++ Nr :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_simulationsstatus.ui" line="84"/>
        <source>Bezeichnung :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_aussengebiete.ui" line="36"/>
        <source>Schacht</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_tezg.ui" line="75"/>
        <source>Regenschreiber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_aussengebiete.ui" line="174"/>
        <source>CN-Wert</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_aussengebiete.ui" line="210"/>
        <source>Höhen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_aussengebiete.ui" line="269"/>
        <source>m NN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_aussengebiete.ui" line="249"/>
        <source>unten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_aussengebiete.ui" line="309"/>
        <source>oben</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_aussengebiete.ui" line="360"/>
        <source>Fließlänge</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_aussengebiete.ui" line="390"/>
        <source>l/(s·ha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_aussengebiete.ui" line="410"/>
        <source>Basisabfluss:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_aussengebiete.ui" line="456"/>
        <source>Objekteigenschaften:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_aussengebiete.ui" line="479"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Flächengröße des Objekts&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_aussengebiete.ui" line="482"/>
        <source>Flächengröße des Objekts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_teilgebiete.ui" line="205"/>
        <source>ha</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_bodenklassen.ui" line="36"/>
        <source>Rückgangskonstante</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_bodenklassen.ui" line="166"/>
        <source>l/m²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_bodenklassen.ui" line="101"/>
        <source>Minimum (Ende)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_bodenklassen.ui" line="153"/>
        <source>Bei Simulationsstart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_bodenklassen.ui" line="179"/>
        <source>Infiltrationsrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_bodenklassen.ui" line="192"/>
        <source>Regenerationskonstante</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_bodenklassen.ui" line="218"/>
        <source>l/(m²·s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_teilgebiete.ui" line="218"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_bodenklassen.ui" line="244"/>
        <source>Sättigungswassergehalt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_bodenklassen.ui" line="337"/>
        <source>Maximum (Anfang)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_teilgebiete.ui" line="36"/>
        <source>Fremdwasseranteil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_teilgebiete.ui" line="88"/>
        <source>h/d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_teilgebiete.ui" line="101"/>
        <source>Wasserverbrauch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_teilgebiete.ui" line="114"/>
        <source>Person/ha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_teilgebiete.ui" line="153"/>
        <source>Stundenmittel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_teilgebiete.ui" line="166"/>
        <source>l/(E·d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_teilgebiete.ui" line="179"/>
        <source>Enwohnerdichte</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_entwaesserungsarten.ui" line="106"/>
        <source>Kürzel :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_entwaesserungsarten.ui" line="135"/>
        <source>Kommentar :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_flaechen.ui" line="36"/>
        <source>Haltung</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_tezg.ui" line="190"/>
        <source>Neigunsklasse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_tezg.ui" line="230"/>
        <source>Abflussparameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_flaechen.ui" line="236"/>
        <source>auf mehrere TEZG-Flächen aufteilen (Verschneidung)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_haltungen.ui" line="57"/>
        <source>Haltungsname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="163"/>
        <source>Schacht oben</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="176"/>
        <source>Schacht unten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_haltungen.ui" line="277"/>
        <source>Haltungsdaten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_haltungen.ui" line="298"/>
        <source>dd.MM.yyyy HH:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_haltungen.ui" line="321"/>
        <source>Profilbreite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_haltungen.ui" line="500"/>
        <source>m </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_haltungen.ui" line="370"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;vorgegebene Haltungslänge, falls diese nicht automatisch berechnet werden soll&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_haltungen.ui" line="373"/>
        <source>vorgegebene Haltungslänge, falls diese nicht automatisch berechnet werden soll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_haltungen.ui" line="419"/>
        <source>Profiltyp</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_haltungen.ui" line="432"/>
        <source>vorgeg. Haltungslänge</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_speicher.ui" line="202"/>
        <source>Entwässerungssystem</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_haltungen.ui" line="523"/>
        <source>Profilhöhe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_haltungen.ui" line="549"/>
        <source>Rauheitsbeiwert</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_kp_abflussparameter.ui" line="175"/>
        <source>Anteil der undurchlässigen Fläche an der Gesamtfläche (0.0 - 1.0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_kp_abflussparameter.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Anteil der undurchlässigen Fläche an der Gesamtfläche (0.0 - 1.0)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_kp_abflussparameter.ui" line="178"/>
        <source>Anteil der undurchlässigen Fläche an der Gesamtfläche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_speicherkennlinien.ui" line="46"/>
        <source>Wasserspiegel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_profildaten.ui" line="92"/>
        <source>Wasserbreite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_pumpen.ui" line="46"/>
        <source>Steuerschacht</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_pumpen.ui" line="59"/>
        <source>Pumpentyp</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_pumpen.ui" line="124"/>
        <source>Ausschalthöhe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_pumpen.ui" line="176"/>
        <source>Sohle</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_pumpen.ui" line="189"/>
        <source>Einschalthöhe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="439"/>
        <source>mNHN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_schaechte.ui" line="237"/>
        <source>Durchmesser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_schaechte.ui" line="263"/>
        <source>Druckdichter Deckel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_schaechte.ui" line="372"/>
        <source>Überstaufläche</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_schaechte.ui" line="395"/>
        <source>m²</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_speicherkennlinien.ui" line="92"/>
        <source>Oberfläche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_swref.ui" line="49"/>
        <source>OI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_swref.ui" line="135"/>
        <source>Rechtswert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_swref.ui" line="158"/>
        <source>l/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_swref.ui" line="178"/>
        <source>Hochwert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_swref.ui" line="201"/>
        <source>Strasse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_swref.ui" line="244"/>
        <source>Nr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_swref.ui" line="257"/>
        <source>Zusatz</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_tezg.ui" line="171"/>
        <source>Parameter für unbefestigte Flächenanteile</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_wehre.ui" line="59"/>
        <source>Überfallbeiwert</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_wehre.ui" line="72"/>
        <source>Außenwasserspiegel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_wehre.ui" line="85"/>
        <source>Kammerhöhe</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_wehre.ui" line="98"/>
        <source>Schieberanfangshöhe</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_wehre.ui" line="111"/>
        <source>Außentyp</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_wehre.ui" line="124"/>
        <source>Schwellenhöhe</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../forms/qkan_wehre.ui" line="137"/>
        <source>Länge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="150"/>
        <source>Schiebergeschwindigkeit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/qkan_wehre.ui" line="452"/>
        <source>m/s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
