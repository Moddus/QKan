<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>ExportToKPDialogBase</name>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="19"/>
        <source>Berechnung der Oberflächenabflussparameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="22"/>
        <source>Export der aktuell geladenen Kanaldaten in eine DYNA-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenexport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="73"/>
        <source>QKan-Projekt-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="98"/>
        <source>Datenquelle: SpatiaLite-Datenbank:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="114"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan-Datenbank (SpatiaLite) mit Kanalnetzdaten auswählen (Standard: Aktuelle QKan-Datenbank) ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="117"/>
        <source>QKan-Datenbank (SpatiaLite) mit Kanalnetzdaten auswählen (Standard: Aktuelle QKan-Datenbank) ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="120"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="139"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten. Hier wird automatisch das aktuelle geladene Projekt eingetragen. Zum Ändern neue SpatiaLite-Datenbank auswählen...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="164"/>
        <source>Auswahl</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="184"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktiviert Auswahl. Wenn deaktiviert, werden alle Teilgebiete berücksichtigt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="187"/>
        <source>Aktiviert Auswahl. Wenn deaktiviert, werden alle Teilgebiete berücksichtigt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="190"/>
        <source>Nur ausgewählte Teilgebiete
berücksichtigen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="204"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Liste der Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="207"/>
        <source>Liste der Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="223"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auswahl Abflussparameter. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="226"/>
        <source>Auswahl Abflussparameter. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="250"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktiviert Auswahl. Wenn deaktiviert, werden alle Abflussparameter berücksichtigt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="253"/>
        <source>Aktiviert Auswahl. Wenn deaktiviert, werden alle Abflussparameter berücksichtigt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="256"/>
        <source>Nur ausgewählte Abflussparameter
berücksichtigen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="276"/>
        <source>Oberflächenabflussparameter ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="450"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Die Berechnung von Fließzeit und Speicherkonstante orientiert sich an HYSTEM-EXTRAN ab Version 7.0&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="453"/>
        <source>Die Berechnung von Fließzeit und Speicherkonstante orientiert sich an HYSTEM-EXTRAN ab Version 7.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="301"/>
        <source>... wie HYSTEM/EXTRAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="324"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Das Querprofil aus der QKan-Tabelle &amp;quot;haltungen&amp;quot; wird anhand der Profilnummer zu den in der DYNA-Vorlagedatei definierten Profilen zugeordnet&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="327"/>
        <source>Das Querprofil aus der QKan-Tabelle &quot;haltungen&quot; wird anhand der Profilnummer zu den in der DYNA-Vorlagedatei definierten Profilen zugeordnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="330"/>
        <source>... wie DYNA/Kanal++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="356"/>
        <source>... nach Maniak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="376"/>
        <source>Berechnungsmodell</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="401"/>
        <source>Speicherkaskade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="427"/>
        <source>Schwerpunktlaufzeit</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="456"/>
        <source>Fließzeiten</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="470"/>
        <source>Aktuell berücksichtigt: </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="490"/>
        <source>Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_runoffparams.ui" line="514"/>
        <source>Anzahl der berücksichtigten Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_runoffparams.ui" line="520"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportFromHEDialogBase</name>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qgsadapt.ui" line="19"/>
        <source>QKan-Projektdatei übertragen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenimport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="66"/>
        <source>Neue Projektdatei</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qgsadapt.ui" line="362"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Suchfenster öffnen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qgsadapt.ui" line="365"/>
        <source>Suchfenster öffnen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="653"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad der neu erzeugten Projektdatei&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="132"/>
        <source>Erzeugte Projektdatei speichern als ... (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="158"/>
        <source>QKan-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="183"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Struktur der QKan-Datenbank wird auf den aktuellen Stand angepasst. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="186"/>
        <source>Struktur der QKan-Datenbank wird auf den aktuellen Stand angepasst.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qgsadapt.ui" line="189"/>
        <source>QKan-Datenbank aktualisieren, falls ältere Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="227"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan - Datenbank, auf die die Projektdatei verweisen soll&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="230"/>
        <source>QKan - Datenbank, auf die die Projektdatei verweisen soll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="253"/>
        <source>QKan-Datenbank (*.sqlite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="276"/>
        <source>Projektdatei als Vorlage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="294"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Projektdatei, die als Vorlage verwendet werden soll&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="297"/>
        <source>Projektdatei, die als Vorlage verwendet werden soll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="320"/>
        <source>Vorlage-Projektdatei (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="343"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Suche der Vorlageprojektdatei beginnt im Template-Verzeichnis&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="346"/>
        <source>Suchverzeichnis vor Vorlageprojektdatei auf Template-Verzeichnis setzen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qgsadapt.ui" line="349"/>
        <source>Standard-QKan-Vorlage verwenden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="19"/>
        <source>Allgmeine QKan-Optionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="57"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Optionen speichern&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="60"/>
        <source>Optionen speichern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="90"/>
        <source>Anbindung an Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="116"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="143"/>
        <source>Fangradius an Haltungen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="165"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximaler Abstand vom Ende der Verbidnungslinie zur zugeordneten Haltung (für manuell erstellte Verbindungslinien). Empfohlener Wert: 0.1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="168"/>
        <source>Maximaler Abstand vom Ende der Verbidnungslinie zur zugeordneten Haltung (für manuell erstellte Verbindungslinien). Empfohlener Wert: 0.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="192"/>
        <source>Wert auf Standardwert (0,10 m) zurücksetzen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="384"/>
        <source>Standwert</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="222"/>
        <source>Mindestflächengröße:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="252"/>
        <source>m²</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="273"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wert auf Standardwert (0,50 m²) zurücksetzen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="276"/>
        <source>Wert auf Standardwert (0,50 m²) zurücksetzen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="298"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Flächen unterhalb der angegebenen Größe werden nicht berücksichtigt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="301"/>
        <source>Mindestgröße zur Berücksichtigung von Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="314"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="336"/>
        <source>Kanal++</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="354"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Grenzwert für die automatische Nummerierung der Haltungen in Haltungssträngen in DYNA&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="357"/>
        <source>Grenzwert für die automatische Nummerierung der Haltungen in Haltungssträngen in DYNA</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="378"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wert auf Standardwert (1000) zurücksetzen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="381"/>
        <source>Wert auf Standardwert (1000) zurücksetzen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="411"/>
        <source>Maximalzahl 
Haltungen pro Strang:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="437"/>
        <source>Datenbanktyp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="460"/>
        <source>QKan-Datenbank: SpatiaLite-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="463"/>
        <source>SpatiaLite (*.sqlite)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="487"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan-Datenbank: PostgreSQL/PostGIS-Datenbankserver&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="490"/>
        <source>QKan-Datenbank: PostgreSQL/PostGIS-Datenbankserver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="493"/>
        <source>PostGIS (PostgreSQL-Datenbankserver)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="515"/>
        <source>Projektionssystem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="535"/>
        <source>Projektionssystem:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="570"/>
        <source>System-Dateien</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="582"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Öffnen der Log-Datei. Enthält viele teilweise interne Informationen über den Verlauf aller aufgerufenen QKan-Plugins, insbesondere Fehlermeldungen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="585"/>
        <source>Log-Datei anzeigen...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="588"/>
        <source>Log-Datei öffnen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="607"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Optional: Pfad zum Editor, mit dem die Log-Datei geöffnet werden soll. Wenn dieses Feld leer ist, wird der Standardeditor gewählt. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="610"/>
        <source>EPSG-Nummer des Projektionssystems der Quelldaten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="631"/>
        <source>Optional: Editor zum Anzeigen der Log-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="647"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Projektionssystem aus QGIS-Liste auswählen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="650"/>
        <source>Projektionssystem aus QGIS-Liste auswählen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="666"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Öffnen der Optionen-Datei (*.json). Enthält alle Grundeinstellungen und viele Verzeichnispfade aus den Formularen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_qkanoptions.ui" line="669"/>
        <source>Optionen-Datei anzeigen...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_qkanoptions.ui" line="672"/>
        <source>Optionen-Datei öffnen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QKanTools</name>
    <message>
        <location filename="../tools/application.py" line="58"/>
        <source>Projektdatei auf bestehende QKan-Datenbank &#xc3;&#xbc;bertragen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/application.py" line="66"/>
        <source>QKan-Projekt aktualisieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/application.py" line="74"/>
        <source>Allgemeine Optionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/application.py" line="82"/>
        <source>Oberfl&#xc3;&#xa4;chenabflussparameter eintragen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/application.py" line="91"/>
        <source>Neue QKan-Datenbank erstellen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/application.py" line="99"/>
        <source>Tabellen importieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/application.py" line="105"/>
        <source>QKan-Datenbank aktualisieren</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>createEmptyDBDialogBase</name>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="19"/>
        <source>Neue QKan-Datenbank anlegen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenimport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="66"/>
        <source>Datenziel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="90"/>
        <source>QKan-Datenbank (*.sqlite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="106"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad und Dateinamen der QKan-Datenbank festlegen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="109"/>
        <source>Pfad und Dateinamen der QKan-Datenbank festlegen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="109"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="131"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Neue QKan - Datenbank mit leeren Tabellen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="134"/>
        <source>Neue QKan - Datenbank mit leeren Tabellen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="153"/>
        <source>Auswahl der Projektionssystems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="172"/>
        <source>Projektionssystem:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="188"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad und Name der Projektdatei festlegen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="210"/>
        <source>Projektdatei (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_emptyDB.ui" line="232"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad der neu erzeugten Projektdatei (optional)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="19"/>
        <source>Daten einfügen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="66"/>
        <source>QKan-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="106"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatenbank auswählen und optional erstellen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="128"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan - Zieldatenbank (wird ggfs. neu angelegt)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="154"/>
        <source>Zu importierende Tabellen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="373"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zu importierende Tabelle auswählen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="376"/>
        <source>Zu importierende Tabelle auswählen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="188"/>
        <source>Schächte:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="204"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schachtdaten aus Clipboard übernehmen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="207"/>
        <source>Schachtdaten aus Clipboard übernehmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="495"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="245"/>
        <source>Auslässe:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="261"/>
        <source>Speicher:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="309"/>
        <source>Haltungen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="341"/>
        <source>Pumpen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_readData.ui" line="357"/>
        <source>Wehre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="389"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auslassdaten aus Clipboard übernehmen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="392"/>
        <source>Auslassdaten aus Clipboard übernehmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="414"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Speicherdaten aus Clipboard übernehmen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="417"/>
        <source>Speicherdaten aus Clipboard übernehmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="439"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Haltungsdaten aus Clipboard übernehmen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="442"/>
        <source>Haltungsdaten aus Clipboard übernehmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="464"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pumpendaten aus Clipboard übernehmen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="467"/>
        <source>Pumpendaten aus Clipboard übernehmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="489"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wehrdaten aus Clipboard übernehmen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_readData.ui" line="492"/>
        <source>Wehrdaten aus Clipboard übernehmen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dbAdaptDialogBase</name>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="19"/>
        <source>Datenbank aktualisieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Anpassung starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="41"/>
        <source>Anpassung starten ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="68"/>
        <source>Zu aktualisierende Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_dbadapt.ui" line="148"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Suchfenster öffnen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_dbadapt.ui" line="151"/>
        <source>Suchfenster öffnen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="154"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="105"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktuelle QKan - Datenbank&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="108"/>
        <source>Aktuelle QKan - Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_dbadapt.ui" line="136"/>
        <source>Geänderte Projektdatei ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="174"/>
        <source>Projektdatei speichern als ... (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_dbadapt.ui" line="196"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad der neu erzeugten Projektdatei&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>layersAdaptDialogBase</name>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="19"/>
        <source>Projektdatei anpassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Anpassung starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="41"/>
        <source>Anpassung starten ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="68"/>
        <source>QKan-Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="88"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;nur aktivierte Layer berücksichtigen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="91"/>
        <source>nur aktivierte Layer berücksichtigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="94"/>
        <source>ausgewählte anpassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="115"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;alle QKan-Layer bearbeiten&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="118"/>
        <source>alle QKan-Layer bearbeiten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="121"/>
        <source>alle anpassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="141"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Fehlende QKan-Layer mit Geodaten entsprechend dem oben gewählten QKan-Standard hinzuladen. Hinweis: Attributtabellen werden auf jeden Fall hinzugeladen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="144"/>
        <source>Fehlende QKan-Geodaten-Layer entsprechend dem oben gewählten QKan-Standard hinzuladen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="147"/>
        <source>Fehlende QKan-Geodaten-
Layer hinzuladen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="170"/>
        <source>Layer anpassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="366"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Formularanbindung für die gewählten QKan-Layern wiederherstellen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="195"/>
        <source>Formularanbindungen auf QKan-Standard setzen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="215"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wertebeziehungen in den gewählten QKan-Layern neu setzten&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="218"/>
        <source>Wertebeziehungen in den gewählten QKan-Layern neu setzten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="221"/>
        <source>Wertbeziehungungen in Tabellen aus QKan-Vorlage anpassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="241"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Projektionssystem für gewählte Layer anpassen. Bei aktiver Datenbankanbindung immer aktiv!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="244"/>
        <source>Projektionssystem für gewählte Layer anpassen. Bei aktiver Datenbankanbindung immer aktiv!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="247"/>
        <source>Projektionssystem an Datenquelle anpassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="267"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Gewählte Layer werden mit angegebener Datenbank verknüpft. Anpassung Projektionssystem wird automatisch aktiviert!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="270"/>
        <source>Gewählte Layer werden mit angegebener Datenbank verknüpft. Anpassung Projektionssystem wird automatisch aktiviert!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="273"/>
        <source>Datenbankanbindung der Layer anpassen (*.sqlite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="438"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Suchfenster öffnen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="441"/>
        <source>Suchfenster öffnen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="444"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="311"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktuelle QKan - Datenbank&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="314"/>
        <source>Aktuelle QKan - Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="337"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nach der Bearbeitung wird der Zoom-Maßstab auf alle geladenen Inhalte angepasst&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="340"/>
        <source>Nach der Bearbeitung wird der Zoom-Maßstab auf alle geladenen Inhalte angepasst</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="343"/>
        <source>Zoom auf alle Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="369"/>
        <source>Projektmakros auf QKan-Standard setzen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="397"/>
        <source>Auswahl der Vorlage</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="422"/>
        <source>Einstellungen aus Projektdatei übernehmen (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="463"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Layereinstellungen aus gewählter Projektdatei übernehmen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="466"/>
        <source>Layereinstellungen aus gewählter Projektdatei übernehmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="489"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan-Standard für die nachfolgenden Anpassungen anwenden&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../tools/res/application_layersadapt.ui" line="492"/>
        <source>QKan-Standard für die nachfolgenden Anpassungen anwenden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="495"/>
        <source>QKan-Standard verwenden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="517"/>
        <source>Auswertung Knotentypen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="536"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In der Tabelle &amp;quot;schaechte&amp;quot; Spalte &amp;quot;knotentyp&amp;quot; erzeugen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="539"/>
        <source>In der Tabelle &quot;schaechte&quot; Spalte &quot;knotentyp&quot; erzeugen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tools/res/application_layersadapt.ui" line="542"/>
        <source>Knotentypen in Tabelle eintragen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
