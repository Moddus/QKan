<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>ExportDialog</name>
    <message>
        <location filename="../xmlporter/application_dialog.py" line="69"/>
        <source>Zu erstellende XML-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/application_dialog.py" line="77"/>
        <source>Zu importierende SQLite-Datei</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportDialog</name>
    <message>
        <location filename="../xmlporter/application_dialog.py" line="124"/>
        <source>Zu importierende XML-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/application_dialog.py" line="133"/>
        <source>Zu erstellende Projektdatei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/application_dialog.py" line="142"/>
        <source>Zu erstellende SQLite-Datei</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XmlPorter</name>
    <message>
        <location filename="../xmlporter/application.py" line="30"/>
        <source>Export nach ISYBAU-XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/application.py" line="37"/>
        <source>Import aus ISYBAU-XML</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xmlexportDialogBase</name>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="14"/>
        <source>Xml-Transfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="62"/>
        <source>Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="160"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="109"/>
        <source>QKan-Datenbank (*.sqlite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="133"/>
        <source>Exportdatei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="180"/>
        <source>ISYBAU-XML-Datei (*.xml):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="205"/>
        <source>Exportieren:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="225"/>
        <source>Speicher</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="246"/>
        <source>Schächte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="267"/>
        <source>Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="288"/>
        <source>Pumpen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="309"/>
        <source>Wehre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../xmlporter/res/xml_export_dialog_base.ui" line="330"/>
        <source>Auslässe</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xmlimportDialogBase</name>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="14"/>
        <source>Xml-Transfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="35"/>
        <source>Projektdatei erzeugen (optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="60"/>
        <source>Projektdatei (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad und Name der Projektdatei festlegen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="315"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="99"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad der neu erzeugten Projektdatei (optional)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="125"/>
        <source>Datenquelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="143"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ITWH-Quelldatenbank mit Kanalnetzdaten auswählen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="166"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten aus HYSTEM-EXTRAN&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="189"/>
        <source>ISYBAU-XML-Datei (*.xml):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="215"/>
        <source>Projektionssystem:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="248"/>
        <source>Datenbank-Verbindungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="273"/>
        <source>Datenziel: QKan-Datenbank (*.sqlite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="296"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan - Zieldatenbank (wird ggfs. neu angelegt)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatenbank auswählen und optional erstellen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="335"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Alle Tabellen, die in QKan vorhanden sind, werden vor dem Export in der HYSTEM-EXTRAN-Datenbank geleert.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="338"/>
        <source>aktiviert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="341"/>
        <source>Tabellen in QKan-Datenbank vor dem Import initialisieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xmlporter/res/xml_import_dialog_base.ui" line="362"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenimport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
