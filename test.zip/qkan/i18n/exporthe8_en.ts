<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>ExportToHE8</name>
    <message>
        <location filename="../exporthe8/application.py" line="33"/>
        <source>Export to Hystem-Extran 8</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportToHEDialogBase</name>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="19"/>
        <source>Export to HE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="22"/>
        <source>Export der aktuell geladenen Kanaldaten in eine Hystem-Extran-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenexport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="72"/>
        <source>QKan-Projekt-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="96"/>
        <source>Datenquelle: SpatiaLite-Datenbank:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="118"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten. Hier wird automatisch das aktuelle geladene Projekt eingetragen. Zum Ändern neue SpatiaLite-Datenbank auswählen...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="147"/>
        <source>Zieldatenbank: HYSTEM-EXTRAN-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="171"/>
        <source>Datenziel: Hystem-Extran-Datenbank (*.idbf):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatenbank mit Kanaldaten für HYSTEM-EXTRAN&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="209"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ITWH-Zieldatenbank angeben ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="212"/>
        <source>ITWH-Zieldatenbank angeben ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="234"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="228"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ITWH-Datenbank mit vorbereiteten Daten als Vorlage auswählen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="231"/>
        <source>ITWH-Datenbank mit vorbereiteten Daten als Vorlage auswählen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="253"/>
        <source>Vorlage: Hystem-Extran-Datenbank (*.idbf):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="291"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Leere ITWH-Datenbank als Vorlage auswählen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="294"/>
        <source>Leere ITWH-Datenbank als Vorlage auswählen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="297"/>
        <source>Leervorlage auswählen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="320"/>
        <source>Tabellen exportieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1708"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Daten aus QKan in der HYSTEM-EXTRAN-Datenbank hinzufügen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1711"/>
        <source>aktiviert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="644"/>
        <source>Haltungen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="667"/>
        <source>Pumpen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="690"/>
        <source>Wehre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="710"/>
        <source>Schächte:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="733"/>
        <source>Auslässe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="756"/>
        <source>Speicher:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="776"/>
        <source>Flächen (RW):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="799"/>
        <source>Abflussparameter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="822"/>
        <source>Regenschreiber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="845"/>
        <source>Rohrprofile:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="868"/>
        <source>Bodenklassen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="888"/>
        <source>Daten</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="909"/>
        <source>neue
hinzufügen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="931"/>
        <source>vorhandene
ändern</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1680"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Die Daten in QKan ändern die entsprechenden Datensätze in der HYSTEM-EXTRAN-Datenbank&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tabellendaten für Regenschreiber können nicht aktualisiert werden. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1260"/>
        <source>alle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1310"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1360"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1386"/>
        <source>keiner:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1437"/>
        <source>Speicherkennlinien:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1459"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tabellendaten für Speicherkennlinien können nicht aktualisiert werden. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1491"/>
        <source>SW-Einleiter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1608"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Die SW-Einleiterdaten werden vor dem Export haltungsweise zusammengefasst, so dass pro Haltung nur ein Datensatz existiert. Dies erhöht die Verarbeitungsgeschwindigkeit in HYSTEM-EXTRAN, während die direkte Zuordnung zu den Geoobjekten in QKan verloren geht. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1634"/>
        <source>zusammen-
fassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1658"/>
        <source>Außengebiete:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1735"/>
        <source>Optionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1754"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;1. Falls in den Tabellen &amp;quot;flaechen&amp;quot; und &amp;quot;einleitsw&amp;quot; leere oder doppelte Namen (flnam bzw. elnam) vorkommen, werden diese mit &amp;quot;f_nnnn&amp;quot; bzw. &amp;quot;e_nnnn&amp;quot; überschrieben. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1757"/>
        <source>Automatische Korrektur von Namensfehlern in den Tabellen &quot;flaechen&quot; und &quot;einleitsw&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1763"/>
        <source>Autokorrektur von Namen in 
Flächen und Einleitpunkten</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1784"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Flächenbilanzierung erfolgt nach Verschneidung der Flächen mit den Haltungsflächen (tezg).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1787"/>
        <source>Flächenbilanzierung erfolgt nach Verschneidung der Flächen mit den Haltungsflächen (tezg).</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1793"/>
        <source>Mit Haltungsflächen
verschneiden</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1814"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zu exportierende Flächen zusätzlich in QKan-Datenbank in Tabelle &amp;quot;flaechen_he8&amp;quot; schreiben&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1817"/>
        <source>Zu exportierende Flächen zusätzlich in QKan-Datenbank in Tabelle &quot;flaechen_he8&quot; schreiben</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1823"/>
        <source>Exportierte Flächen in
QKan-Tabelle kopieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1845"/>
        <source>Nur ausgewählte Teilgebiete berücksichtigen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1858"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auswahl Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1861"/>
        <source>Auswahl Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1884"/>
        <source>Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1999"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="1930"/>
        <source>Aktuell berücksichtigt: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../exporthe8/application_dialog_base.ui" line="1976"/>
        <source>Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../exporthe8/application_dialog_base.ui" line="2022"/>
        <source>Schächte</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
