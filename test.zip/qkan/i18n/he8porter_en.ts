<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>ExportDialog</name>
    <message>
        <location filename="../he8porter/application_dialog.py" line="149"/>
        <source>Vorlage f&#xc3;&#xbc;r die zu erstellende HE8-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/application_dialog.py" line="161"/>
        <source>Zu erstellende HE8-Datei</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportToHEDialogBase</name>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="19"/>
        <source>Export to HE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="22"/>
        <source>Export der aktuell geladenen Kanaldaten in eine Hystem-Extran-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenexport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="72"/>
        <source>QKan-Projekt-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="96"/>
        <source>Datenquelle: SpatiaLite-Datenbank:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="118"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten. Hier wird automatisch das aktuelle geladene Projekt eingetragen. Zum Ändern neue SpatiaLite-Datenbank auswählen...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="147"/>
        <source>Zieldatenbank: HYSTEM-EXTRAN-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="171"/>
        <source>Datenziel: Hystem-Extran-Datenbank (*.idbf):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatenbank mit Kanaldaten für HYSTEM-EXTRAN&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="209"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ITWH-Zieldatenbank angeben ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="212"/>
        <source>ITWH-Zieldatenbank angeben ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="234"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="228"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ITWH-Datenbank mit vorbereiteten Daten als Vorlage auswählen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="231"/>
        <source>ITWH-Datenbank mit vorbereiteten Daten als Vorlage auswählen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="253"/>
        <source>Vorlage: Hystem-Extran-Datenbank (*.idbf):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="300"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Suche in Vorlagenverzeichnis starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="735"/>
        <source>aktiviert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="309"/>
        <source>Suche in Vorlagenverzeichnis starten ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="335"/>
        <source>Tabellen exportieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bodenklassen exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="365"/>
        <source>Bodenklassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="384"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Einzugsflächen exportieren, die als &amp;quot;Haltungsfläche&amp;quot; markiert sind&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="390"/>
        <source>Haltungsflächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="412"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pumpen exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="418"/>
        <source>Pumpen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="437"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schächte exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="1016"/>
        <source>Schächte</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="462"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auslässe exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="468"/>
        <source>Auslässe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="490"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Speicherbauwerke exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="496"/>
        <source>Speicher</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="515"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Flächenobjekte und Daten exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="521"/>
        <source>Flächen (RW)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="540"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sonderprofile exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="546"/>
        <source>Sonderprofile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="565"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Haltungen exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="970"/>
        <source>Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="616"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abflussparameter exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="622"/>
        <source>Abflussparameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="644"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wehre exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="650"/>
        <source>Wehre</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="669"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Außengebiete exportieren und Kreisflächen aus Flächenzahl erzeugen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="675"/>
        <source>Außengebiete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="694"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Direkteinleiter als Punkte und mit Daten exportieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="700"/>
        <source>SW-Einleiter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="732"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Einzugsgebiete exportieren (umfasst nur Tabellendaten)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="738"/>
        <source>Einzugsgebiete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="759"/>
        <source>Optionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="778"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;1. Falls in den Tabellen &amp;quot;flaechen&amp;quot; und &amp;quot;einleitsw&amp;quot; leere oder doppelte Namen (flnam bzw. elnam) vorkommen, werden diese mit &amp;quot;f_nnnn&amp;quot; bzw. &amp;quot;e_nnnn&amp;quot; überschrieben. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="781"/>
        <source>Automatische Korrektur von Namensfehlern in den Tabellen &quot;flaechen&quot; und &quot;einleitsw&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="787"/>
        <source>Autokorrektur von Namen in 
Flächen und Einleitpunkten</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="808"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Flächenbilanzierung erfolgt nach Verschneidung der Flächen mit den Haltungsflächen (tezg).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="811"/>
        <source>Flächenbilanzierung erfolgt nach Verschneidung der Flächen mit den Haltungsflächen (tezg).</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="817"/>
        <source>Mit Haltungsflächen
verschneiden</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="839"/>
        <source>Nur ausgewählte Teilgebiete berücksichtigen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="852"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auswahl Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="855"/>
        <source>Auswahl Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="878"/>
        <source>Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="993"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="924"/>
        <source>Aktuell berücksichtigt: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="1035"/>
        <source>Aktionen beim Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="1053"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Überschreiben aller Attribute von bereits vorhandenen Datensätzen. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="1056"/>
        <source>Aktualisieren bereits vorhandenen Datensätzen. </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="1059"/>
        <source>ändern</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="1078"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Hinzufügen noch nicht vorhandene Datensätze&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="1081"/>
        <source>Hinzufügen noch nicht vorhandene Datensätze</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_export_dialog_base.ui" line="1084"/>
        <source>hinzufügen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>He8Porter</name>
    <message>
        <location filename="../he8porter/application.py" line="35"/>
        <source>Export nach Hystem-Extran 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/application.py" line="42"/>
        <source>Import aus Hystem-Extran 8</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportDialog</name>
    <message>
        <location filename="../he8porter/application_dialog.py" line="436"/>
        <source>Zu importierende HE8-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/application_dialog.py" line="445"/>
        <source>Zu erstellende Projektdatei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/application_dialog.py" line="454"/>
        <source>Zu erstellende SQLite-Datei</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportFromHEDialogBase</name>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="19"/>
        <source>QKan Import from Hystem-Extran</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenimport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="66"/>
        <source>Datenquelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="90"/>
        <source>Datenquelle: Hystem-Extran-Datenbank (*.idbf):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="106"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ITWH-Quelldatenbank mit Kanalnetzdaten auswählen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="282"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="128"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten aus HYSTEM-EXTRAN&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="150"/>
        <source>Projektionssystem:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="186"/>
        <source>Projektdatei erzeugen (optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="210"/>
        <source>Projektdatei (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="226"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad und Name der Projektdatei festlegen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="248"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad der neu erzeugten Projektdatei (optional)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="274"/>
        <source>Datenziel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="298"/>
        <source>QKan-Datenbank (*.sqlite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="314"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatenbank auswählen und optional erstellen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="336"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan - Zieldatenbank (wird ggfs. neu angelegt)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="362"/>
        <source>Tabellen importieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="386"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Haltungen importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="819"/>
        <source>aktiviert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="392"/>
        <source>Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="411"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schächte importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="417"/>
        <source>Schächte</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="436"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Flächenobjekte und Daten importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="442"/>
        <source>Flächen (RW)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="461"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auslässe importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="467"/>
        <source>Auslässe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="489"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Speicherbauwerke importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="495"/>
        <source>Speicher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="517"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pumpen importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="523"/>
        <source>Pumpen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="545"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wehre importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="551"/>
        <source>Wehre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="570"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sonderprofile importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="576"/>
        <source>Sonderprofile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="595"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abflussparameter importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="601"/>
        <source>Abflussparameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="620"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bodenklassen importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="626"/>
        <source>Bodenklassen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="645"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Direkteinleiter als Punkte und mit Daten importieren&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="651"/>
        <source>SW-Einleiter</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="683"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Außengebiete importieren und Kreisflächen aus Flächenzahl erzeugen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="689"/>
        <source>Außengebiete</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="722"/>
        <source>Haltungsfläche, markiert als:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="741"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Einzugsflächen importieren, die als &amp;quot;Einzugsfläche&amp;quot; markiert sind&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="747"/>
        <source>Einzugsflächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="766"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Einzugsflächen importieren, die als &amp;quot;Haltungsfläche&amp;quot; markiert sind&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="772"/>
        <source>Haltungsflächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="791"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Einzugsflächen importieren, die als &amp;quot;TW-Einzugsfläche&amp;quot; markiert sind&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="797"/>
        <source>TW-Einzugsflächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="816"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Einzugsgeebiete importieren (enthält nur Attributdaten)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="822"/>
        <source>Einzugsgebiete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="842"/>
        <source>Aktionen beim Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="860"/>
        <source>Hinzufügen, aktualisieren und Löschen von Datensätzen in der QKan-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="863"/>
        <source>Synchronisation der QKan-Daten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="866"/>
        <source>synchronisieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="885"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Überschreiben aller Attribute von bereits vorhandenen Datensätzen. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="888"/>
        <source>Aktualisieren bereits vorhandenen Datensätzen. </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="891"/>
        <source>ändern</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="910"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Hinzufügen noch nicht vorhandene Datensätze&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="913"/>
        <source>Hinzufügen noch nicht vorhandene Datensätze</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_import_dialog_base.ui" line="916"/>
        <source>hinzufügen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="66"/>
        <source>Datenbank-Verbindungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="90"/>
        <source>Einzulesende Ergebnis-Datenbank (*.idbf):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="150"/>
        <source>Thematische Darstellung für die Ergebnisse:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="172"/>
        <source>Überstauhäufigkeiten aus einer Seriensimulation farbig darstellen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="175"/>
        <source>Überstauhäufigkeiten (nur für Seriensimulationen)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="194"/>
        <source>Überstauvolumina farbig darstellen (für Einzel- und Seriensimulation)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="197"/>
        <source>Überstauvolumina</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="216"/>
        <source>Ausgewählte Stildatei verwenden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="219"/>
        <source>eigene Stildatei:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="238"/>
        <source>Standarddarstellung verwenden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="241"/>
        <source>ohne</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="263"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Stildatei zur thematischen Darstellung der Ergebnisse&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../he8porter/res/he8_results_dialog_base.ui" line="279"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Stildatei zur thematischen Darstellung der Ergebnisse auswählen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
