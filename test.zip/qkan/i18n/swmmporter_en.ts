<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>ExportToSWMMDialogBase</name>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="19"/>
        <source>Export in eine SWMM-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="22"/>
        <source>Export der aktuell geladenen Kanaldaten in eine SWMM-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenexport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="73"/>
        <source>QKan-Projekt-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="98"/>
        <source>Datenquelle: SpatiaLite-Datenbank:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="114"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan-Datenbank (SpatiaLite) mit Kanalnetzdaten auswählen (Standard: Aktuelle QKan-Datenbank) ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="117"/>
        <source>QKan-Datenbank (SpatiaLite) mit Kanalnetzdaten auswählen (Standard: Aktuelle QKan-Datenbank) ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="255"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="139"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten. Hier wird automatisch das aktuelle geladene Projekt eingetragen. Zum Ändern neue SpatiaLite-Datenbank auswählen...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="166"/>
        <source>Ziel: SWMM-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="191"/>
        <source>Datenziel: SWMM-Datei (*.ein):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="214"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatei mit Kanaldaten für SWMM&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="230"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;SWMM-Zieldatei angeben ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="233"/>
        <source>SWMM-Zieldatei angeben ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="249"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;SWMM-Datei mit vorbereiteten Daten als Vorlage auswählen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="252"/>
        <source>SWMM-Datei mit vorbereiteten Daten als Vorlage auswählen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="275"/>
        <source>Vorlage: SWMM-Datei (*.ein):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="298"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vorlagedatei für SWMM-Export, kann schon Daten enthalten&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="322"/>
        <source>Allgemeine Optionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="341"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;1. Falls in den Tabellen &amp;quot;flaechen&amp;quot; und &amp;quot;einleitsw&amp;quot; leere oder doppelte Namen (flnam bzw. elnam) vorkommen, werden diese mit &amp;quot;f_nnnn&amp;quot; bzw. &amp;quot;e_nnnn&amp;quot; überschrieben. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="344"/>
        <source>Automatische Korrektur von Namensfehlern in den Tabellen &quot;flaechen&quot; und &quot;einleitsw&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="347"/>
        <source>Fehlende Profile in Tabelle &quot;profile&quot; ergänzen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="368"/>
        <source>Berechnung des Befestigungsgrades aus ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="387"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Befestigungsgrad ist Quotient aus Summe der befestigten Flächen und der Haltungsfläche (tezg)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="390"/>
        <source>Befestigungsgrad ist Quotient aus Summe der befestigten Flächen und der Haltungsfläche (tezg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="393"/>
        <source>... Haltungsflächen (tezg) und befestigten Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="413"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Befestigungsgrade werden aus den Quotienten der Summen der befestigten und der Summen der unbefestigten Flächen ermittelt. Es werden also nur die Daten aus Tabelle &amp;quot;flaechen&amp;quot; verwendet. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="416"/>
        <source>Befestigungsgrad aus befestigten und unbefestigten Flächen ermitteln</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="419"/>
        <source>... befestigten und unbefestigten Flächenobjekten</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="439"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Flächenbilanzierung erfolgt nach Verschneidung der Flächen mit den Haltungsflächen (tezg).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="442"/>
        <source>Flächenbilanzierung erfolgt nach Verschneidung der Flächen mit den Haltungsflächen (tezg).</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="448"/>
        <source>Mit Haltungsflächen verschneiden</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="462"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auswahl Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="465"/>
        <source>Auswahl Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="609"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="516"/>
        <source>Flächen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/exportSWMM.ui" line="537"/>
        <source>Haltungen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="558"/>
        <source>Aktuell berücksichtigt: </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="633"/>
        <source>Schächte:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/exportSWMM.ui" line="654"/>
        <source>Nur ausgewählte Teilgebiete
berücksichtigen:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportFromHEDialogBase</name>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="14"/>
        <source>QKan Import aus SWMM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="33"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenimport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="62"/>
        <source>Datenbank-Verbindungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="87"/>
        <source>Datenziel: QKan-Datenbank (*.sqlite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan - Zieldatenbank (wird ggfs. neu angelegt)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/importSWMM.ui" line="125"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatenbank auswählen und optional erstellen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="262"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="152"/>
        <source>Projektdatei erzeugen (optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="177"/>
        <source>Projektdatei (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="193"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad und Name der Projektdatei festlegen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="215"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad der neu erzeugten Projektdatei (optional)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="241"/>
        <source>Datenquelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../swmmporter/res/importSWMM.ui" line="259"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ITWH-Quelldatenbank mit Kanalnetzdaten auswählen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="282"/>
        <source>Projektionssystem:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="304"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten aus HYSTEM-EXTRAN&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swmmporter/res/importSWMM.ui" line="327"/>
        <source>SWMM-Datei (*.inp):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportFromSWMM</name>
    <message>
        <location filename="../swmmporter/application.py" line="60"/>
        <source>Import aus SWMM-Datei (*.INP)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
