<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>DynaPorter</name>
    <message>
        <location filename="../dynaporter/__init__.py" line="27"/>
        <source>Export in DYNA-Datei...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/__init__.py" line="35"/>
        <source>Import aus DYNA-Datei (*.EIN)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportToKPDialogBase</name>
    <message>
        <location filename="../dynaporter/res/export.ui" line="19"/>
        <source>Export in eine DYNA-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="22"/>
        <source>Export der aktuell geladenen Kanaldaten in eine DYNA-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenexport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="73"/>
        <source>QKan-Projekt-Datenbank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="98"/>
        <source>Datenquelle: SpatiaLite-Datenbank:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="114"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan-Datenbank (SpatiaLite) mit Kanalnetzdaten auswählen (Standard: Aktuelle QKan-Datenbank) ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="117"/>
        <source>QKan-Datenbank (SpatiaLite) mit Kanalnetzdaten auswählen (Standard: Aktuelle QKan-Datenbank) ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="255"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="139"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten. Hier wird automatisch das aktuelle geladene Projekt eingetragen. Zum Ändern neue SpatiaLite-Datenbank auswählen...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="166"/>
        <source>Ziel: DYNA-Datei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="191"/>
        <source>Datenziel: DYNA-Datei (*.ein):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="214"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatei mit Kanaldaten für DYNA&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="230"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;DYNA-Zieldatei angeben ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="233"/>
        <source>DYNA-Zieldatei angeben ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="249"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;DYNA-Datei mit vorbereiteten Daten als Vorlage auswählen ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="252"/>
        <source>DYNA-Datei mit vorbereiteten Daten als Vorlage auswählen ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="275"/>
        <source>Vorlage: DYNA-Datei (*.ein):</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="298"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vorlagedatei für DYNA-Export, kann schon Daten enthalten&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="322"/>
        <source>Allgemeine Optionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="341"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;1. Falls in den Tabellen &amp;quot;flaechen&amp;quot; und &amp;quot;einleitsw&amp;quot; leere oder doppelte Namen (flnam bzw. elnam) vorkommen, werden diese mit &amp;quot;f_nnnn&amp;quot; bzw. &amp;quot;e_nnnn&amp;quot; überschrieben. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="344"/>
        <source>Automatische Korrektur von Namensfehlern in den Tabellen &quot;flaechen&quot; und &quot;einleitsw&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="347"/>
        <source>Fehlende Profile in Tabelle &quot;profile&quot; ergänzen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="367"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatische Festlegung der DYNA-spezifischen Kanal- und Haltungsnummern. Bereits vorhandene Nummern werden überschrieben. Diese Option verändert nicht die Haltungsnamen. &lt;/p&gt;&lt;p&gt;Ist die Option nicht aktiviert, wird versucht, Kanal- und Haltungsnummer aus dem Haltungsnamen zu ermitteln (KN(8) - HN(3)).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="370"/>
        <source>Automatische Festlegung der DYNA-spezifischen Kanal- und Haltungsnummern. Bereits vorhandene Nummern werden überschrieben. Diese Option verändert nicht die Haltungsnamen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="373"/>
        <source>Automatische Vergabe der Kanal- und Haltungsnummern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="394"/>
        <source>Zuordnung der Profile anhand...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="413"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Das Querprofil aus der QKan-Tabelle &amp;quot;haltungen&amp;quot; wird anhand des Profilnamens zu den in der DYNA-Vorlagedatei definierten Profilen zugeordnet&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="416"/>
        <source>Das Querprofil aus der QKan-Tabelle &quot;haltungen&quot; wird anhand des Profilnamens zu den in der DYNA-Vorlagedatei definierten Profilen zugeordnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="419"/>
        <source>... Profilname (Langbezeichnung)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="439"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Das Querprofil aus der QKan-Tabelle &amp;quot;haltungen&amp;quot; wird anhand der Profilnummer zu den in der DYNA-Vorlagedatei definierten Profilen zugeordnet&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="442"/>
        <source>Das Querprofil aus der QKan-Tabelle &quot;haltungen&quot; wird anhand der Profilnummer zu den in der DYNA-Vorlagedatei definierten Profilen zugeordnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="445"/>
        <source>... Profilschlüssel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="466"/>
        <source>Berechnung des Befestigungsgrades aus ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="485"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Befestigungsgrad ist Quotient aus Summe der befestigten Flächen und der Haltungsfläche (tezg)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="488"/>
        <source>Befestigungsgrad ist Quotient aus Summe der befestigten Flächen und der Haltungsfläche (tezg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="491"/>
        <source>... Haltungsflächen (tezg) und befestigten Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="511"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Befestigungsgrade werden aus den Quotienten der Summen der befestigten und der Summen der unbefestigten Flächen ermittelt. Es werden also nur die Daten aus Tabelle &amp;quot;flaechen&amp;quot; verwendet. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="514"/>
        <source>Befestigungsgrad aus befestigten und unbefestigten Flächen ermitteln</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="517"/>
        <source>... befestigten und unbefestigten Flächenobjekten</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="537"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Flächenbilanzierung erfolgt nach Verschneidung der Flächen mit den Haltungsflächen (tezg).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="540"/>
        <source>Flächenbilanzierung erfolgt nach Verschneidung der Flächen mit den Haltungsflächen (tezg).</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="546"/>
        <source>Mit Haltungsflächen verschneiden</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="560"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auswahl Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="563"/>
        <source>Auswahl Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="707"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="614"/>
        <source>Flächen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/export.ui" line="635"/>
        <source>Haltungen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="656"/>
        <source>Aktuell berücksichtigt: </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="731"/>
        <source>Schächte:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/export.ui" line="752"/>
        <source>Nur ausgewählte Teilgebiete
berücksichtigen:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportFromHEDialogBase</name>
    <message>
        <location filename="../dynaporter/res/import.ui" line="14"/>
        <source>QKan Import aus DYNA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="33"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenimport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="62"/>
        <source>Datenbank-Verbindungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="87"/>
        <source>Datenziel: QKan-Datenbank (*.sqlite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;QKan - Zieldatenbank (wird ggfs. neu angelegt)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/import.ui" line="125"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zieldatenbank auswählen und optional erstellen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="262"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="152"/>
        <source>Projektdatei erzeugen (optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="177"/>
        <source>Projektdatei (*.qgs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="193"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad und Name der Projektdatei festlegen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="215"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad der neu erzeugten Projektdatei (optional)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="241"/>
        <source>Datenquelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../dynaporter/res/import.ui" line="259"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ITWH-Quelldatenbank mit Kanalnetzdaten auswählen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="282"/>
        <source>Projektionssystem:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="304"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quelldatenbank mit Kanaldaten aus HYSTEM-EXTRAN&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../dynaporter/res/import.ui" line="327"/>
        <source>DYNA-Datei (*.ein):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
