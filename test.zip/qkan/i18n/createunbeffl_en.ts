<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>CreateUnbefFl</name>
    <message>
        <location filename="../createunbeffl/application.py" line="26"/>
        <source>Erzeuge unbefestigte Fl&#xc3;&#xa4;chen...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportFromHEDialogBase</name>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="14"/>
        <source>QKan Erzeugen von unbefestigten Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../createunbeffl/application_dialog_base.ui" line="33"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bearbeitung starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auswahl Haltungsflächenarten. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="58"/>
        <source>Auswahl Haltungsflächenarten. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="87"/>
        <source>Erzeugen von unbefestigten Flächenobjekten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../createunbeffl/application_dialog_base.ui" line="113"/>
        <source>Optionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="132"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;1. Falls in der Tabelle &amp;quot;tezg&amp;quot; leere oder doppelte Namen (flnam) vorkommen, werden diese mit &amp;quot;ft_nnnn&amp;quot; überschrieben. &lt;/p&gt;&lt;p&gt;2. Falls in der Tabelle &amp;quot;abflussfaktoren&amp;quot; kein Datensatz für unbefestigte Flächen existiert (Kriterium: bodenklasse = NULL), wird ein entsprechender Datensatz &apos;$Default_Bef&apos; ergänzt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../createunbeffl/application_dialog_base.ui" line="135"/>
        <source>Automatische Korrektur von Datenfehlern in der Tabelle &quot;tezg&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="138"/>
        <source>Autokorrektur von Namen und Abflussfaktoren
in den TEZG-Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vor Beginn der Bearbeitung werden zunächst in den Tabellen &amp;quot;Flächen&amp;quot; und &amp;quot;Haltungsflächen&amp;quot; geometrische Fehler korrigiert.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="162"/>
        <source>Vor Beginn der Bearbeitung werden zunächst in den Tabellen &quot;Flächen&quot; und &quot;Haltungsflächen&quot; geometrische Fehler korrigiert.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="168"/>
        <source>Flächenobjekte bereinigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="192"/>
        <source>Auswahl der zu bearbeitenden Arten von Haltungsflächen (tezg):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../createunbeffl/application_dialog_base.ui" line="221"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../createunbeffl/application_dialog_base.ui" line="250"/>
        <source>Ausgewählte Haltungsflächen:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
