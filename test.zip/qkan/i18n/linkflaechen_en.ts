<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>ConnectDialogBase</name>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_managegroups.ui" line="19"/>
        <source>Aus Verbindungslinien zugeordnete Haltungen in Flächen eintragen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenimport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="67"/>
        <source>Auswahloptionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="104"/>
        <source>diesem ausgewählten Teilgebiet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="117"/>
        <source>innerhalb</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="130"/>
        <source>überlappend</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="143"/>
        <source>Haltungen und Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="156"/>
        <source>zuordnen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="200"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nur bei Auswahl &amp;quot;innerhalb&amp;quot;: die Fläche der Teilgebiete wird bei der Suche um die Pufferbreite vergrößert, um kleine Ungenauigkeiten zu berücksichtigen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="203"/>
        <source>Pufferbreite: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="226"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="249"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Falls in der Tabelle &amp;quot;tezg&amp;quot; leere oder doppelte Namen (flnam) vorkommen, werden diese mit &amp;quot;ft_nnnn&amp;quot; überschrieben. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="252"/>
        <source>Autokorrektur der TEZG-Namen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="272"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vor Beginn der Bearbeitung werden zunächst in den Tabellen &amp;quot;Flächen&amp;quot; und &amp;quot;Haltungsflächen&amp;quot; geometrische Fehler korrigiert.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="275"/>
        <source>Vor Beginn der Bearbeitung werden zunächst in den Tabellen &quot;Flächen&quot; und &quot;Haltungsflächen&quot; geometrische Fehler korrigiert.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_assigntgeb.ui" line="281"/>
        <source>Flächenobjekte bereinigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="67"/>
        <source>Teilgebietszuordnungen verwalten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="104"/>
        <source>Gespeicherte Gruppen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="133"/>
        <source>Teilgebiet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="138"/>
        <source>Tabelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="143"/>
        <source>Anzahl</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_managegroups.ui" line="157"/>
        <source>Datensätze für gewählte Gruppe:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="178"/>
        <source>Aus Gruppe wiederherstellen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="199"/>
        <source>Neue Gruppe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="235"/>
        <source>Bezeichnung:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="256"/>
        <source>Kommentar:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_managegroups.ui" line="293"/>
        <source>Neue Gruppe speichern</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportFromHEDialogBase</name>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="19"/>
        <source>Verbindungslinien erstellen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Datenimport starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="67"/>
        <source>Filteroptionen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="88"/>
        <source>Liste der in den Flächen verwendeten Abflussparameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="111"/>
        <source>Tabelle Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="280"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Liste der in den Haltungen verwendeten Entwässerungssysteme./nStrg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="133"/>
        <source>Liste der in den Haltungen verwendeten Entwässerungssysteme. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="85"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Liste der Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="88"/>
        <source>Liste der Teilgebiete. Strg + Klick ändert Auswahlstatus, Shift + Klick erweitert Auswahlbereich</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="306"/>
        <source>Tabelle Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="261"/>
        <source>Allgemein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="208"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="238"/>
        <source>Aktuell berücksichtigt:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="324"/>
        <source>aufzuteilende Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="387"/>
        <source>ganze Flächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="178"/>
        <source>Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="440"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktiviert Auswahl. Wenn deaktiviert, werden alle Abflussparameter berücksichtigt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="443"/>
        <source>Aktiviert Auswahl. Wenn deaktiviert, werden alle Abflussparameter berücksichtigt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="446"/>
        <source>Nur ausgewählte Abfluss-
parameter berücksichtigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="400"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktiviert Auswahl. Wenn deaktiviert, werden alle Entwässerungssysteme berücksichtigt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="403"/>
        <source>Aktiviert Auswahl. Wenn deaktiviert, werden alle Entwässerungssysteme berücksichtigt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="406"/>
        <source>Nur ausgewählte Entwässe-
rungssysteme berücksichtigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="427"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktiviert Auswahl. Wenn deaktiviert, werden alle Teilgebiete berücksichtigt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="430"/>
        <source>Aktiviert Auswahl. Wenn deaktiviert, werden alle Teilgebiete berücksichtigt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="433"/>
        <source>Nur ausgewählte Teilgebiete
berücksichtigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="525"/>
        <source>Optionen zur Erzeugung von Zuordnungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="380"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="332"/>
        <source>Suchradius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="598"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Radius, innerhalb dessen zu einer Fläche die nächste Haltung gesucht wird&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="601"/>
        <source>Maximaler Suchabstand zwischen Fläche und Haltung</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="621"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Abstand zwischen Mitte der Fläche und Haltung&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="624"/>
        <source>Abstand zwischen Mitte der Fläche und Haltung</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="627"/>
        <source>Abstand zum Mittelpunkt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="647"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Der Abstand wird von der Kante der Fläche aus ermittelt, die der Haltung am nächsten ist&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="650"/>
        <source>Der Abstand wird von der Kante der Fläche aus ermittelt, die der Haltung am nächsten ist</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="653"/>
        <source>Abstand zur nächsten Kante</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="673"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Falls in den Tabellen &amp;quot;flaechen&amp;quot; und &amp;quot;einleitsw&amp;quot; leere oder doppelte Namen (flnam bzw. elnam) vorkommen, werden diese mit &amp;quot;f_nnnn&amp;quot; bzw. &amp;quot;e_nnnn&amp;quot; überschrieben. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="676"/>
        <source>Automatische Korrektur von Namensfehlern...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="682"/>
        <source>Autokorrektur von Namen in Flächen und Einleitpunkten</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="702"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Verbindungslinien berücksichtigen nur Haltungen innerhalb derselben Haltungsfläche&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="705"/>
        <source>Verbindungslinien berücksichtigen nur Haltungen innerhalb derselben Haltungsfläche</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="711"/>
        <source>Verbindungen nur innerhalb Haltungsfläche (tezg) erstellen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="731"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Berücksichtigung von Haltungsflächen: Die Verbindungslinien werden zu jeder Teilfläche angelegt, die sich aus der Verschneidung der Flächen und der Haltungsflächen ergeben. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="734"/>
        <source>Verbindungslinien werden nach Verschneidung der Flächen mit den Haltungsflächen erstellt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="740"/>
        <source>Mit Haltungsflächen verschneiden</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="760"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vor Beginn der Bearbeitung werden zunächst in den Tabellen &amp;quot;Flächen&amp;quot; und &amp;quot;Haltungsflächen&amp;quot; geometrische Fehler korrigiert.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="763"/>
        <source>Vor Beginn der Bearbeitung werden zunächst in den Tabellen &quot;Flächen&quot; und &quot;Haltungsflächen&quot; geometrische Fehler korrigiert.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="769"/>
        <source>Flächenobjekte bereinigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="795"/>
        <source>Fangradius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="817"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximaler Abstand vom Ende der Verbidnungslinie zur zugeordneten Haltung (für manuell erstellte Verbindungslinien). Empfohlener Wert: 0.1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="820"/>
        <source>Maximaler Abstand vom Ende der Verbidnungslinie zur zugeordneten Haltung (für manuell erstellte Verbindungslinien). Empfohlener Wert: 0.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinefl.ui" line="868"/>
        <source>Warnung</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="67"/>
        <source>Auswahl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="118"/>
        <source>Direkteinleitungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_createlinesw.ui" line="283"/>
        <source>Liste der in den Haltungen verwendeten Entwässerungssysteme</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LinkFl</name>
    <message>
        <location filename="../linkflaechen/application.py" line="51"/>
        <source>Alle Elemente des Entw&#xc3;&#xa4;sserungsnetzes zu Teilgebiet zuordnen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/application.py" line="61"/>
        <source>Erzeuge Verkn&#xc3;&#xbc;pfungslinien von Fl&#xc3;&#xa4;chen zu Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/application.py" line="69"/>
        <source>Erzeuge Verkn&#xc3;&#xbc;pfungslinien von Direkteinleitungen zu Haltungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/application.py" line="79"/>
        <source>Verkn&#xc3;&#xbc;pfungen bereinigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/application.py" line="87"/>
        <source>Teilgebietszuordnungen als Gruppen verwalten</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QKan_updateLinks</name>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="19"/>
        <source>Verknüpfungen bereinigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bereinigung starten ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="41"/>
        <source>Bereinigung starten ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="69"/>
        <source>Datenbank-Verbindungen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="94"/>
        <source>Aktuelle QKan-Datenbank:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="116"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktuell zu bearbeitende QKan-Datenbank&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="145"/>
        <source>Fangradius auf Haltungen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="187"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="210"/>
        <source>Flächenverknüpfungen bereinigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="230"/>
        <source>Einzeleinleitern-Verknüpfungen bereinigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="250"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sollen Datensätze in der Tabelle &amp;quot;linkfl&amp;quot;, die kein Linienobjekt haben, gelöscht werden?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="253"/>
        <source>Sollen Datensätze in der Tabelle &quot;linkfl&quot;, die kein Linienobjekt haben, gelöscht werden?</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="256"/>
        <source>Datensätze ohne Linienobjekt löschen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="276"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Vor Beginn der Bearbeitung werden zunächst in den Tabellen &amp;quot;Flächen&amp;quot; und &amp;quot;Haltungsflächen&amp;quot; geometrische Fehler korrigiert.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="279"/>
        <source>Vor Beginn der Bearbeitung werden zunächst in den Tabellen &quot;Flächen&quot; und &quot;Haltungsflächen&quot; geometrische Fehler korrigiert.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="285"/>
        <source>Flächenobjekte bereinigen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../linkflaechen/res/application_updatelinks.ui" line="304"/>
        <source>Warnung</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
