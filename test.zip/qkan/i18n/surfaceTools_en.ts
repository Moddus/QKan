<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context encoding="UTF-8">
    <name>Dialog</name>
    <message encoding="UTF-8">
        <location filename="../surfaceTools/surfaceTool.ui" line="14"/>
        <source>Flächenbereinigung</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../surfaceTools/surfaceTool.ui" line="61"/>
        <source>Masterflächen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../surfaceTools/surfaceTool.ui" line="81"/>
        <source>anzupassende Flächen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SurfaceTools</name>
    <message>
        <location filename="../surfaceTools/application.py" line="43"/>
        <source>Solve Overlap of Layers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
